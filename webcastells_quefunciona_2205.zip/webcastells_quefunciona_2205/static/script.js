// ================================
// FUNCIONS: REC/STOP i TEMPORITZADOR
// ================================
const recBtn = document.getElementById('rec-button');
const videoWrapper = document.getElementById('video-wrapper');
const recordingIndicator = document.getElementById('recording-indicator');
const timerDisplay = document.getElementById('rec-time');
const saveBtn = document.getElementById('save-button');

let isRecording = false;
let interval = null;
let seconds = 0;

function formatTime(s) {
  const h = String(Math.floor(s / 3600)).padStart(2, '0');
  const m = String(Math.floor((s % 3600) / 60)).padStart(2, '0');
  const sec = String(s % 60).padStart(2, '0');
  return `${h}:${m}:${sec}`;
}

function startTimer() {
  seconds = 0;
  timerDisplay.textContent = '00:00:00';
  interval = setInterval(() => {
    seconds++;
    timerDisplay.textContent = formatTime(seconds);
  }, 1000);
}

function stopTimer() {
  clearInterval(interval);
  interval = null;
}




// ================================
// GESTIÓ NAVEGACIÓ ENTRE PANTALLES (Z-INDEX) I MENÚ
// ================================
const navLinks = document.querySelectorAll('.menu-option');
const screens = document.querySelectorAll('.screen');
const sideMenu = document.getElementById('side-menu');
const menuToggleButtons = document.querySelectorAll('.menu-toggle');
const menuClose = document.getElementById('menu-close');

menuToggleButtons.forEach(btn => {
  btn.addEventListener('click', () => {
    sideMenu.classList.add('open');
  });
});

menuClose.addEventListener('click', () => {
  sideMenu.classList.remove('open');
});

function activateScreen(targetId) {
  screens.forEach(s => {
    s.style.zIndex = '0';
    s.style.display = 'none';
  });
  const target = document.getElementById(`screen-${targetId}`);
  if (target) {
    target.style.zIndex = '10';
    target.style.display = 'flex';
  }
}

navLinks.forEach(link => {
  link.addEventListener('click', () => {
    navLinks.forEach(l => l.classList.remove('active'));
    link.classList.add('active');

    let targetId = 'live';
    if (link.textContent.includes('VIDEO')) targetId = 'video';
    if (link.textContent.includes('LIVE')) targetId = 'live';
    if (link.textContent.includes('DATA')) targetId = 'data';

    activateScreen(targetId);
    sideMenu.classList.remove('open');
  });
});


activateScreen('live');


// ================================
// CHART.JS: Gràfiques en temps real
// ================================
function createAngleChart(canvasId) {
  const ctx = document.getElementById(canvasId).getContext('2d');
  return new Chart(ctx, {
    type: 'line',
    data: {
      labels: [],
      datasets: [{
        label: 'Angle',
        data: [],
        borderColor: 'black',
        borderWidth: 2.5,
        tension: 0.4,
        pointRadius: 0,
      }]
    },
    options: {
      animation: false,
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          display: false,
          min: 165,
          max: 185
        },
        x: {
          display: false
        }
      },
      plugins: {
        legend: { display: false },
        tooltip: { enabled: false }
      }
    }
  });
}

function updateVideoCharts(angle1, angle2, chartA, chartB, labelA, labelB) {
  const MAX = 50;

  chartA.data.labels.push('');
  chartB.data.labels.push('');
  chartA.data.datasets[0].data.push(angle1);
  chartB.data.datasets[0].data.push(angle2);

  if (chartA.data.labels.length > MAX) {
    chartA.data.labels.shift();
    chartA.data.datasets[0].data.shift();
    chartB.data.labels.shift();
    chartB.data.datasets[0].data.shift();
  }

  document.getElementById(labelA).textContent = `${angle1}°`;
  document.getElementById(labelB).textContent = `${angle2}°`;

  chartA.update();
  chartB.update();
}


const chart1 = createAngleChart('chart-angle-1');
const chart2 = createAngleChart('chart-angle-2');
const chart3 = createAngleChart('chart-angle-3');
const chart4 = createAngleChart('chart-angle-4');



console.log("🔁 Executant updateLiveCharts...");



function updateLiveCharts() {
  fetch('/angles_live')
    .then(res => res.json())
    .then(data => {
      console.log("📈 Dades rebudes:", data);

      chart1.data.labels.push('');
      chart2.data.labels.push('');
      chart1.data.datasets[0].data.push(data.angle1);
      chart2.data.datasets[0].data.push(data.angle2);

      const MAX = 50;
      if (chart1.data.labels.length > MAX) {
        chart1.data.labels.shift();
        chart1.data.datasets[0].data.shift();
      }
      if (chart2.data.labels.length > MAX) {
        chart2.data.labels.shift();
        chart2.data.datasets[0].data.shift();
      }

      chart1.update();
      chart2.update();

      document.getElementById('label-angle-1').textContent = `${data.angle1}°`;
      document.getElementById('label-angle-2').textContent = `${data.angle2}°`;
    });
}

setInterval(updateLiveCharts, 1000);



// ================================
// VIDEO PLAYER - Selecció d'arxiu
// ================================
const videoFileInput = document.getElementById('video-file');
const videoPlayer = document.getElementById('video-player');
const videoUploadButton = document.querySelector('.video-upload-button');
const playButton = document.getElementById('play-button');
const videoTime = document.getElementById('video-time');
const timelineTrack = document.getElementById('custom-timeline');

videoFileInput.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (file) {
    const url = URL.createObjectURL(file);
    videoPlayer.src = url;
    videoPlayer.load();
    videoUploadButton.style.display = 'none';
  }
});

playButton.addEventListener('click', () => {
  if (videoPlayer.paused) {
    videoPlayer.play();
    playButton.classList.add('stop');
    playButton.textContent = 'STOP';
  } else {
    videoPlayer.pause();
    playButton.classList.remove('stop');
    playButton.textContent = 'PLAY';
  }
});

videoPlayer.addEventListener('timeupdate', () => {
  if (videoPlayer.duration) {
    const progressPercent = (videoPlayer.currentTime / videoPlayer.duration) * 100;
    timelineTrack.style.setProperty('--progress', `${progressPercent}%`);

    const seconds = Math.floor(videoPlayer.currentTime);
    const h = String(Math.floor(seconds / 3600)).padStart(2, '0');
    const m = String(Math.floor((seconds % 3600) / 60)).padStart(2, '0');
    const s = String(seconds % 60).padStart(2, '0');
    videoTime.textContent = `${h}:${m}:${s}`;

    updateVideoCharts(175 + Math.sin(seconds), 173 + Math.cos(seconds), chart3, chart4, 'label-angle-3', 'label-angle-4');
  }
});

timelineTrack.addEventListener('click', (e) => {
  const rect = timelineTrack.getBoundingClientRect();
  const percent = (e.clientX - rect.left) / rect.width;
  const time = percent * videoPlayer.duration;
  videoPlayer.currentTime = time;
});


document.getElementById('rec-button').addEventListener('click', () => {
  console.log("✅ Has fet clic a REC!");

  fetch('/rec', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'start' })
  })
  .then(res => res.json())
  .then(data => console.log("🎬 Resposta del backend:", data))
  .catch(err => console.error("❌ Error al rec:", err));
});


recBtn.addEventListener('click', () => {
  isRecording = !isRecording;

  alert("🎥 Has premut el botó REC!");


  // Aparença del botó
  if (isRecording) {
    recBtn.textContent = '■ STOP';
    recBtn.classList.add('recording');
    videoWrapper.classList.add('recording');
    recordingIndicator.style.display = 'block';
    saveBtn.disabled = true;
    startTimer();

    // 👉 Crida al backend per començar la gravació
    console.log("🔴 Enviant REC: start");

    fetch('/rec', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ action: 'start' })
    })
    .then(res => res.json())
    .then(data => console.log("🎬 Backend response:", data))
    .catch(err => console.error("❌ Error en START REC:", err));

  } else {
    recBtn.textContent = '● REC';
    recBtn.classList.remove('recording');
    videoWrapper.classList.remove('recording');
    recordingIndicator.style.display = 'none';
    saveBtn.disabled = false;
    stopTimer();

    // 👉 Crida al backend per parar la gravació
    console.log("🔴 Enviant REC: stop");

    fetch('/rec', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ action: 'stop' })
    })
    .then(res => res.json())
    .then(data => console.log("🛑 Backend response:", data))
    .catch(err => console.error("❌ Error en STOP REC:", err));
  }
});
