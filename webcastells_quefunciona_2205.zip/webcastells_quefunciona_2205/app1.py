from flask import Flask, render_template, Response, jsonify
import subprocess
import cv2
import cv2.aruco as aruco
import math
import numpy as np
import json
from datetime import datetime
from picamera2 import Picamera2
import time

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/numeritos')
def numeritos():
    return jsonify({"numeritos": [1, 2, 3, 4]})

@app.route("/iniciar-deteccion", methods=["POST"])
def iniciar_deteccion():
    try:
        subprocess.Popen(["python", "scripts/detector_aruco.py"])
        return jsonify({"estado": "La detección se ha iniciado"})
    except Exception as e:
        return jsonify({"estado": f"Error al iniciar la detección: {e}"}), 500

@app.route('/video_feed')
def video_feed():
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

def calcular_angulo_360(p1, p2, p3):
    v1 = np.array(p1) - np.array(p2)
    v2 = np.array(p3) - np.array(p2)
    angulo_rad = math.atan2(v2[1], v2[0]) - math.atan2(v1[1], v1[0])
    angulo_deg = math.degrees(angulo_rad)
    return int(round(angulo_deg + 360)) % 360

def gen_frames():
    from picamera2 import Picamera2
    picam2 = Picamera2()
    config = picam2.create_video_configuration(main={"format": 'RGB888', "size": (640, 480)})
    picam2.configure(config)
    picam2.start()
    
    aruco_dict = aruco.getPredefinedDictionary(aruco.DICT_4X4_50)
    parameters = aruco.DetectorParameters_create()

    ultimos_centros = {}
    data_angles = {}
    start_time = time.time()

    try:
        while True:
            frame = picam2.capture_array()
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            corners, ids, _ = aruco.detectMarkers(gray, aruco_dict, parameters=parameters)

            marcadores_actuales = {}

            if ids is not None:
                for i, marker_id in enumerate(ids.flatten()):
                    c = corners[i][0]
                    cX, cY = int(np.mean(c[:, 0])), int(np.mean(c[:, 1]))

                    if marker_id not in marcadores_actuales:
                        marcadores_actuales[marker_id] = []
                    marcadores_actuales[marker_id].append((cX, cY))

                for marker_id in marcadores_actuales:
                    puntos_actuales = marcadores_actuales[marker_id]
                    if len(puntos_actuales) == 4:
                        ultimos_centros[marker_id] = sorted(puntos_actuales, key=lambda p: p[1])
                    else:
                        if marker_id not in ultimos_centros:
                            ultimos_centros[marker_id] = puntos_actuales
            else:
                ultimos_centros.clear()

            for marker_id, puntos in ultimos_centros.items():
                if len(puntos) == 4:
                    p1, p2, p3, p4 = puntos
                    angulo1 = calcular_angulo_360(p1, p2, p3)
                    angulo2 = calcular_angulo_360(p2, p3, p4)
                    elapsed_time = int(time.time() - start_time)

                    # Dibuixar
                    cv2.line(frame, p1, p2, (0, 255, 0), 2)
                    cv2.line(frame, p2, p3, (0, 255, 0), 2)
                    cv2.circle(frame, p1, 5, (0, 255, 0), -1)
                    cv2.circle(frame, p2, 5, (0, 255, 0), -1)
                    cv2.circle(frame, p3, 5, (0, 255, 0), -1)
                    cv2.circle(frame, p4, 5, (0, 255, 0), -1)
                    cv2.line(frame, p3, p4, (0, 255, 0), 2)

                    cv2.putText(frame, f"{angulo1}°", p2, cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
                    cv2.putText(frame, f"{angulo2}°", p3, cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)

                    # Guardar a JSON
                    if marker_id not in data_angles:
                        data_angles[marker_id] = []

                    data_angles[marker_id].append({
                        "segundo": elapsed_time,
                        "angle1": angulo1,
                        "angle2": angulo2
                    })

                    angle_data_str_keys = {str(k): v for k, v in data_angles.items()}
                    with open("static/angles.json", "w") as f:
                        json.dump(angle_data_str_keys, f)

            ret, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

    except GeneratorExit:
        print("[INFO] Stream tancat pel client.")
    finally:
        picam2.stop()
        picam2.close()
        print("[INFO] Càmera alliberada.")


if __name__ == "__main__":
    app.run(host='0.0.0.0', port=80, debug=True)
